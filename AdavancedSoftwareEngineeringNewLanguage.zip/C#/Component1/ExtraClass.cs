﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Collections;

namespace Component1
{
    /// <summary>
    /// Vriables neeed for the programm have been declared here. 
    /// Array,string, integer with different modifiers depending on the reusability of the variable
    /// </summary>
    public class ExtraClass
    {
        //LocalDataStoreSlot all the vriable
        static IDictionary<string, int> variable = new Dictionary<string, int>();
        //sotres all the methods and the umber of parameters used int he method
        static IDictionary<string, ArrayList> method = new Dictionary<string, ArrayList>();
        //storethe variable used in the method.
        ArrayList method_variable = new ArrayList();
        private static ExtraClass instance = null;
       //stores the operator like >=, <=, !=,>,<
        static string operators = "";

        /// <summary>
        /// Uses the singleton design pattern and creates an instance of this class.
        /// </summary>
        public static ExtraClass GetInstance
        {
            get
            {
                if (instance == null)
                    instance = new ExtraClass();
                return instance;
            }
        }


        /// <summary>
        /// This method clears all the variable, method nas method_variable list.
        /// </summary>
        public void Clear_List()
        {
            variable.Clear();
            method.Clear();
            method_variable.Clear();
        }


       /// <summary>
       /// This method returns the variablelist
       /// </summary>
       /// <returns>variable</returns>
        public static IDictionary<string, int> getVariables()
        {
            return variable;
        }


        /// <summary>
        ///  This method returns the methodlist
        /// </summary>
        /// <returns>method</returns>
        public static IDictionary<string, ArrayList> getMethodSignature()
        {
            return method;
        }


        /// <summary>
        /// Execution and logic of the if commnad.
        /// </summary>
        /// <param name="okay">Is the commands list</param>
        /// <param name="lines">total line count</param>
        /// <param name="current_line">current line in which the iff command is in</param>
        /// <param name="frm">Reference of the Form1 class</param>
        /// <returns>true</returns>
        public bool if_command(string okay, string[] lines, int current_line, Form1 frm)
        {
            int has_endif = 0;
            for (int a = current_line; a < lines.Length; a++)
            {
                if (lines[a].Equals("endif"))
                {
                    has_endif++;
                }
            }
            if (has_endif == 0 && !lines[current_line].Equals("then"))
            {
                frm.ConsoleTextBox.AppendText("If block not ended properly!");
                return false;
            }
            if (lines[current_line].Equals("then")&&lines.Length >= current_line + 3)
            {
                frm.ConsoleTextBox.AppendText("Multi line command can only be executed by endif not then!");
                return false;
            }
            operators = CommandParser.getOperator();
            string newCondition = okay.Split('(', ')')[1].Trim();
            string[] splitCon = newCondition.Split(new String[] {operators}, StringSplitOptions.RemoveEmptyEntries);
            try
            {
                if (splitCon.Length == 2)
                {
                    string keys = splitCon[0].Trim();
                    int value = int.Parse(splitCon[1].Trim());
                    if (variable.ContainsKey(keys))
                    {
                        int initial = 0;
                        variable.TryGetValue(keys, out initial);

                        bool returns = false;

                        int value1 = initial;    //previous value
                        int value2 = value;       //value after operator
                        switch (operators)
                        {
                            case "<=":
                                if (value1 <= value2)
                                    returns = true;
                                break;

                            case ">=":
                                if (value1 >= value2)
                                    returns = true;
                                break;

                            case "==":
                                if (value1 == value2)
                                    returns = true;
                                break;

                            case "!=":
                                if (value1 != value2)
                                    returns = true;
                                break;

                            case "<":
                                if (value1 < value2)
                                    returns = true;
                                break;

                            case ">":
                                if (value1 > value2)
                                    returns = true;
                                break;
                        }
                        if (returns)
                        {
                            if (lines[current_line].Equals("then"))
                            {
                               
                                string command_kind = CommandParser.GetInstance.type_check(lines[current_line + 1]);

                                if (command_kind.Equals("valid"))
                                {

                                    if (CommandParser.GetInstance.all_check(lines[current_line + 1]))
                                    {

                                        frm.draw_cmds(lines[current_line + 1]);

                                    }
                                }
                               
                            }
                           
                            else
                            {
                                for (int i = (current_line); i < lines.Length; i++)
                                {
                                    if (!(lines[i].Equals("endif")))
                                    {
                                        string type = CommandParser.GetInstance.type_check(lines[i]);
                                        if (type.Equals("valid"))
                                        {
                                            if (CommandParser.GetInstance.all_check(lines[i]))
                                            {
                                                frm.draw_cmds(lines[i]);
                                            }
                                        }
                                        else if (type.Equals("variableOperator"))
                                        {
                                            if (CommandParser.GetInstance.variable_operator(lines[i]))
                                            {
                                                operations(lines[1], frm);
                                            }
                                        }
                                        else
                                        {
                                            frm.ConsoleTextBox.AppendText("Wrong command!");
                                            return false;
                                        }
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                            }
                            //break;
                        }
                        else
                        {
                            frm.ConsoleTextBox.AppendText("Error on line" + current_line + ":Operator did not match!");
                            return false;
                        }
                    }

                    else
                    {
                        //case false:
                        throw new VariableException("Variable Doesnot exist!");
                    }
                }
                else
                {
                    frm.ConsoleTextBox.AppendText("Error on line" + current_line + ": If condition is invalid!!!");
                }
            }
            catch(VariableException e)
            {
                frm.ConsoleTextBox.AppendText(e.Message);
                return false;
            }
            return true;


          
        }
        //****************************************************
        /// <summary>
        ///  Execution and logic of the loop commnad.
        /// </summary>
        /// <param name="okay">Is the commands list</param>
        /// <param name="lines">total line count</param>
        /// <param name="current_loop_line">current line in which the loop command is in</param>
        /// <param name="frm">Reference of the Form1 class</param>
        /// <returns>true</returns>
        public bool loop_comd(string okay, string[] lines, int current_loop_line, Form1 frm)
        {
            int loop_end = 0;
            for (int i = loop_end; i < lines.Length; i++)
            {
                if (lines[i].Equals("endloop"))
                {
                    loop_end++;
                }
            }
            if (loop_end == 0)
            {
                frm.ConsoleTextBox.AppendText("Error: Please close the loop!");
                return false;
            }
            string[] command_okay = okay.Split(new string[] { "for" }, StringSplitOptions.RemoveEmptyEntries);
            int initial_Value = 0;
            int addition = 0;
            string[] condition = command_okay[1].Split(new string[] { "<=", ">=", "<", ">" }, StringSplitOptions.RemoveEmptyEntries);
            string name = condition[0].ToLower().Trim();
            int current_value = int.Parse(condition[1].Trim());
            ArrayList cmd = new ArrayList();
            if (variable.ContainsKey(name))
            {
                variable.TryGetValue(name, out initial_Value);
                for (int i = (current_loop_line); i < lines.Length; i++)
                {
                    if (!(lines[i].Equals("endloop")))
                    {
                        cmd.Add(lines[i]);
                    }
                    else
                    {
                        break;
                    }
                    if ((lines[i].Contains(name + "+") || lines[i].Contains(name + "-")||lines[i].Contains(name + "*")|| lines[i].Contains(name + "/")))
                    {
                        addition++;
                    }

                }
                if (addition == 0)
                {
                    frm.ConsoleTextBox.AppendText("The variable have not been assigned to any operator for theloop to work!");
                    return false; 
                }
                if (command_okay[1].Contains("<="))
                {
                    if (initial_Value >= current_value)
                    {
                        frm.ConsoleTextBox.AppendText("The operation does not match the condition!");
                        return false;
                    }
                    while (initial_Value <= current_value)
                    {
                        foreach(string comd in cmd)
                        {
                            string type = CommandParser.GetInstance.type_check(comd);
                            if (type.Equals("valid"))
                            {
                                if (CommandParser.GetInstance.all_check(comd))
                                {
                                    frm.draw_cmds(comd);
                                }
                                    
                            }
                            else if (type.Equals("variableOperator"))
                            {
                                if (CommandParser.GetInstance.variable_operator(comd))
                                {
                                    operations(comd, frm);
                                }
                            }
                            else
                            {
                                frm.ConsoleTextBox.AppendText("Commadn is not correct!");
                                return false;
                            }
                        }
                        //this store the immediate increased value in the key value pair that will be changes in the next round!
                        variable.TryGetValue(name, out initial_Value);
                    }
                }
                else if (command_okay[1].Contains(">="))
                {
                    if (initial_Value <= current_value)
                    {
                        frm.ConsoleTextBox.AppendText("The operation does not match the condition!");
                        return false;
                    }
                    while (initial_Value >= current_value)
                    {
                        foreach (string comd in cmd)
                        {
                            string type = CommandParser.GetInstance.type_check(comd);
                            if (type.Equals("valid"))
                            {
                                if (CommandParser.GetInstance.all_check(comd))
                                {
                                    frm.draw_cmds(comd);
                                }

                            }
                            else if (type.Equals("variableOperator"))
                            {
                                if (CommandParser.GetInstance.variable_operator(comd))
                                {
                                    operations(comd, frm);
                                }
                            }
                            else
                            {
                                frm.ConsoleTextBox.AppendText("Commadn is not correct!");
                                return false;
                            }
                        }
                        variable.TryGetValue(name, out initial_Value);
                    }
                }
                else if (command_okay[1].Contains("<"))
                {
                    if (initial_Value > current_value)
                    {
                        frm.ConsoleTextBox.AppendText("The operation does not match the condition!");
                        return false;
                    }
                    while (initial_Value < current_value)
                    {
                        foreach (string comd in cmd)
                        {
                            string type = CommandParser.GetInstance.type_check(comd);
                            if (type.Equals("valid"))
                            {
                                if (CommandParser.GetInstance.all_check(comd))
                                {
                                    frm.draw_cmds(comd);
                                }

                            }
                            else if (type.Equals("variableOperator"))
                            {
                                if (CommandParser.GetInstance.variable_operator(comd))
                                {
                                    operations(comd, frm);
                                }
                            }
                            else
                            {
                                frm.ConsoleTextBox.AppendText("Commadn is not correct!");
                                return false;
                            }
                        }
                        variable.TryGetValue(name, out initial_Value);
                    }
                }
               else if (command_okay[1].Contains(">"))
                {
                    if (initial_Value < current_value)
                    {
                        frm.ConsoleTextBox.AppendText("The operation does not match the condition!");
                        return false;
                    }
                    while (initial_Value > current_value)
                    {
                        foreach (string comd in cmd)
                        {
                            string type = CommandParser.GetInstance.type_check(comd);
                            if (type.Equals("valid"))
                            {
                                if (CommandParser.GetInstance.all_check(comd))
                                {
                                    frm.draw_cmds(comd);
                                }

                            }
                            else if (type.Equals("variableOperator"))
                            {
                                if (CommandParser.GetInstance.variable_operator(comd))
                                {
                                    operations(comd, frm);
                                }
                            }
                            else
                            {
                                frm.ConsoleTextBox.AppendText("Commadn is not correct!");
                                return false;
                            }
                        }
                        variable.TryGetValue(name, out initial_Value);
                    }
                }
                else
                {
                    
                    return false;
                }
               
            }
            return true;
        }


        //***************************************************

        //Method run
        /// <summary>
        /// Execution and logic of the method commnad
        /// </summary>
        /// <param name="okay">Is the commands list</param>
        /// <param name="lines">total line count</param>
        /// <param name="running_line">current line in which the method command is in</param>
        /// <param name="frm">Reference of the Form1 class</param>
        /// <returns>true</returns>
        public bool method_run(string okay, string[] lines, int running_line, Form1 frm)
        {
            int method_end = 0;
            for(int a = running_line; a < lines.Length ; a++)
            {
                if (lines[a].Equals("endmethod"))
                {
                    method_end++;
                }
            }
            if(method_end == 0)
            {
                frm.ConsoleTextBox.AppendText("Error: Method end missing!");
                return false;
            }
            //running_line miltiline command with mre than 1 parameter
            string[] commnad_parts = okay.Split(new string[] { "(" }, StringSplitOptions.RemoveEmptyEntries);
            string inside = commnad_parts[1];
            inside = Regex.Replace(inside, @"\s+", "");
            string commnads_cms = commnad_parts[0] + "(" + inside;
            //splitting the commands fro the space "" in the array 0,1,2
            string[] commands = commnads_cms.Split(new string[] {" "}, StringSplitOptions.RemoveEmptyEntries);
            string mth_name = commands[1].Trim();
            mth_name = Regex.Replace(mth_name, @"\s+", "");
            int param_count = 0;
            string parameter_value = commands[2].Trim().Split('(', ')')[1];
            ArrayList commands_method = new ArrayList();
            for(int i = running_line; i < lines.Length; i++)
            {
                if (!lines[i].Equals("endmethod"))
                {
                    commands_method.Add(lines[i]);
                }
                else
                {
                    break;
                }
            }
            if (parameter_value.Contains(','))
            {
                param_count = parameter_value.Split(',').Length;
                foreach(string varibaleName in parameter_value.Split(','))
                {
                   method_variable.Add(varibaleName);
                }
            }
            else
            {
                if (parameter_value.Length > 0)
                {
                    param_count = 1;
                    method_variable.Add(parameter_value);
                }
                else
                {
                    param_count = 0;
                }
            }
            string keys = mth_name + "," + param_count;
            if (!method.ContainsKey(keys))
            {
                method.Add(keys, commands_method);
            }
            else
            {
                frm.ConsoleTextBox.AppendText("Method already existes!");
            }
            return true;

        }
        //method run end



        /// <summary>
        /// //calling th method command
        /// </summary>
        /// <param name="okay">method name and its parameter</param>
        /// <param name="frm">Reference of the Form1 class</param>
        /// <returns>true</returns>
        public bool method_call(string okay, Form1 frm)
        {
            string methodname = okay.Split('(')[0];
            methodname = Regex.Replace(methodname, @"\s+", "");
            string para_value = okay.Trim().Split('(', ')')[1];
            int param_count = 0;
            if (para_value.Contains(','))
            {
                param_count = para_value.Split(',').Length;
                for(int i=0; i<param_count; i++)
                {
                    if (!variable.ContainsKey((string)method_variable[i]))
                    {
                        variable.Add((string)method_variable[i], int.Parse(para_value.Split(',')[i]));
                    }
                    else
                    {
                        variable[(string)method_variable[i]] = int.Parse(para_value.Split(',')[i]);
                    }
                }
            }
            else
            {
                if (para_value.Length > 0)
                {
                    param_count = 1;
                    if (!variable.ContainsKey((string)method_variable[0]))
                    {
                        variable.Add((string)method_variable[0], int.Parse(para_value));
                    }
                    else
                    {
                        variable[(string)method_variable[0]] = int.Parse(para_value);
                    }
                }
                else
                {
                    param_count = 0;
                }
            }
            string final = methodname.Trim() + "," + param_count;
            ArrayList commands = new ArrayList();
            method.TryGetValue(final, out commands);
            foreach(string cmd in commands)
            {
                string type = CommandParser.GetInstance.type_check(cmd);
                //checking for method without parameter
                if (type.Equals("valid"))
                {
                    if (CommandParser.GetInstance.all_check(cmd))
                    {
                        frm.draw_cmds(cmd);
                    }
                }

                //checking foe method with parameter nad operators
                else if (type.Equals("variableOperator"))
                {
                    if (CommandParser.GetInstance.variable_operator(cmd))
                    {
                        operations(cmd, frm);
                    }

                }
                else
                {
                    frm.ConsoleTextBox.AppendText("Command not found: " + cmd);
                    return false;
                }
            }
            return true;

        }
        //ending the method call cmd



       /// <summary>
       /// adds the varibale in the variable list.
       /// </summary>
       /// <param name="okay">varibale command passed formt he form1 class</param>
       /// <returns>true</returns>
        public bool variable_command(string okay)
        {
            okay = Regex.Replace(okay, @"\s+", "");
            string name = okay.Split('=')[0].Trim();
            int value = int.Parse(okay.Split('=')[1].Trim());
            if (!variable.ContainsKey(name))
            {
               
                variable.Add(name, value);

            }
            else
            {
                variable[name] = value;
            }
            return true;

        }


        /// <summary>
        /// executes the logic of the variable operation
        /// </summary>
        /// <param name="okay">varibale command passed formt he form1 class with operators</param>
        /// <param name="frm">Reference of the Form1 class</param>
        /// <returns>true</returns>
        public bool operations(string okay, Form1 frm)
        {
            try
            {
                string[] variables = okay.Split(new char[] { '+', '-', '*', '/' }, StringSplitOptions.RemoveEmptyEntries);
                int operation_count = 0;
                if (variables.Length != 2)
                {
                    //return false if radius + 1 is not operation_count 2
                    return false;
                }
                for (int i = 0; i < okay.Length; i++)
                {
                    if (okay[i].Equals('+') || okay[i].Equals('-') || okay[i].Equals('*') || okay[i].Equals('/'))
                    {
                        operation_count++;
                    }
                }
                if (operation_count > 1)
                {
                    return false;
                }
                string keyVar = variables[0].Trim();
                string valueVar = variables[1].Trim();
                int Number = Int32.Parse(valueVar);
                int actual_value = 0; //this will store thr initial value of the variable.
                if (variable.ContainsKey(keyVar))
                {
                    variable.TryGetValue(keyVar, out actual_value);
                    if (okay.Contains("+"))
                    {
                        variable[keyVar] = actual_value + Number;
                    }
                    else if (okay.Contains("-"))
                    {
                        variable[keyVar] = actual_value - Number;
                    }
                    else if (okay.Contains("*"))
                    {
                        variable[keyVar]=actual_value * Number;
                    }
                    else if (okay.Contains("/"))
                    {
                        variable[keyVar]=actual_value / Number;
                    }

                }
                else
                {
                    throw new VariableException("Variable does not exist!");
                }
            }
            catch(VariableException e)
            {
                frm.ConsoleTextBox.AppendText(e.Message);
                return false;
            }
            return true;
        }
    }
}
