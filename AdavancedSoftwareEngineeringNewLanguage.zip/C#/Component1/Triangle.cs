﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading;
namespace Component1
{
    /// <summary>
    /// new class rectangle is created from te base class shape
    /// </summary>
    class Triangle : Shape
    {
        int side1;
        int side2;
        int side3;
       
        bool flashing = false;
        /// <summary>
        ///  calling  the base class constructor
        /// </summary>
        public Triangle() : base()
        {

        }


        /// <summary>
        /// overloading the constructor
        /// </summary>
        /// <param name="color">the colour for the shape to be drawn in</param>
        /// <param name="fill">fillinf the shape with the color on/off</param>
        /// <param name="flashs">flashinf the colors in the color on/off</param>
        /// <param name="x">x-axis coordinate</param>
        /// <param name="y">y-axis coordinate</param>
        /// <param name="side1">First side of the triangle</param>
        /// <param name="side2">Second side of the triangle</param>
        /// <param name="side3">Third side of the triangle</param>
        public Triangle(Color color, bool fill, bool flashs, int x, int y, int side1, int side2, int side3) : base(color, fill,flashs, x, y)
        {
            this.side1 = side1;
            this.side2 = side2;
            this.side3 = side3;
        }


        /// <summary>
        ///   /// implementing the virtual method set where num[0] and 
        /// num[1] are x and y resepctively and num[2] is the height and
        /// num[3] is width
        /// </summary>
        /// <param name="colour"></param>
        /// <param name="fillshape"></param>
        /// <param name="flash"></param>
        /// <param name="num"></param>
        public override void Set(Color colour, bool fillshape,bool flash, params int[] num)
        {
            base.Set(colour, fillshape,flash, num[0], num[1]);
            this.side1 = num[2];
            this.side2 = num[3];
            this.side3 = num[4];
        }
        /// <summary>
        /// the draw method of base class is overridded
        /// </summary>
        /// <param name="g">Reference of grahics</param>
        public override void Draw(Graphics g)
        {
            if (Form1.RotateShape() != 0)
            {
                float rotateValue = (float)Form1.RotateShape();
                g.RotateTransform((rotateValue), MatrixOrder.Append);
            }
            Pen p = new Pen(c, 2);
            SolidBrush b = new SolidBrush(c);
            PointF[] vertex = new PointF[3];
            
            vertex[0].X = x;    //initial point 0,0
            vertex[0].Y = y;

            vertex[1].X = x + side1;  //second point 0+side1, y=0
            vertex[1].Y = y;

            vertex[2].X = x + side2;  //final point side1+side2, y=0+side3 
            vertex[2].Y = y + side3;


            if (fillshape==true)
            {
                g.FillPolygon(b,vertex);
            }
            else if (fillshape == false){
                    Pen p2 = new Pen(c, 5);
                    SolidBrush b2 = new SolidBrush(Color.White);
                    g.DrawPolygon(p2, vertex);
                    g.FillPolygon(b2, vertex);   
            }
            else
            {
                g.DrawPolygon(p, vertex);
            }
            if (flash == true)
            {
                while (true)
                {
                    if (flashing == false)
                    {

                        Pen p6 = new Pen(c, 2);
                        SolidBrush b6 = new SolidBrush(c);
                        g.FillPolygon(b6, vertex);
                        flashing = true;
                    }
                    else
                    {
                        if (c == Color.Red)
                        {
                            Pen p6 = new Pen(c, 2);
                            SolidBrush b2 = new SolidBrush(Color.Green);
                            g.FillPolygon(b2, vertex);
                            flashing = false;
                        }
                        else if (c == Color.Blue)
                        {
                            Pen p6 = new Pen(c, 2);
                            SolidBrush b2 = new SolidBrush(Color.Yellow);
                            g.FillPolygon(b2, vertex);
                            flashing = false;
                        }
                        else if (c == Color.Black)
                        {
                            Pen p6 = new Pen(c, 2);
                            SolidBrush b2 = new SolidBrush(Color.White);
                            g.FillPolygon(b2, vertex);
                            flashing = false;
                        }

                    }
                    Thread.Sleep(500);
                    continue;
                }

            }
        }
    }
}
