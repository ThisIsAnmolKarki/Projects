﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading;
namespace Component1
{
    /// <summary>
    /// new class rectangle is created from te base class shape
    /// </summary>
    class Rectangle : Shape
    {
        int height;
        int width;

        bool flashing = false;

        public static bool running2 = false;
       
        /// <summary>
        ///  calling  the base class constructor
        /// </summary>
        public Rectangle() : base()
        {

        }
        /// <summary>
        /// overloading the constructoer
        /// </summary>
        /// <param name="color">the colour for the shape to be drawn in</param>
        /// <param name="fill">filling the shape with the color on/off</param>
        /// <param name="flash">flashing the colors in the color on/off</param>
        /// <param name="x">x-axis cooerdinate</param>
        /// <param name="y">y-axis coordinate</param>
        /// <param name="height">height of the rectangle</param>
        /// <param name="width">width of the rectangle</param>
        public Rectangle(Color color, bool fill, bool flash, int x, int y, int height, int width) : base(color, fill, flash, x, y)
        {
            this.height = height;
            this.width = width;
        }

        /// <summary>
        ///    /// implementing the virtual method set where num[0] and 
        /// num[1] are x and y resepctively and num[2] is the height and
        /// num[3] is width
        /// </summary>
        /// <param name="colour"></param>
        /// <param name="fillshape"></param>
        /// <param name="flashs"></param>
        /// <param name="num"></param>
        public override void Set(Color colour, bool fillshape, bool flashs, params int[] num)
        {
            base.Set(colour, fillshape, flashs, num[0], num[1]);
            this.height = num[2];
            this.width = num[3];
        }


        /// <summary>
        /// the draw method of base class is overridded
        /// </summary>
        /// <param name="g">reference of the grahics class</param>
        public override void Draw(Graphics g)
        {
            if (Form1.RotateShape() != 0)
            {
                float rotateValue = (float)Form1.RotateShape();
                g.RotateTransform((rotateValue), MatrixOrder.Append);
            }
            Pen p = new Pen(c, 2);
            SolidBrush b = new SolidBrush(c);
            if (fillshape == true)
            {
                g.FillRectangle(b, x, y, height, width);
            }
            else if (fillshape == false)
            {
                Pen p2 = new Pen(c, 2);
                SolidBrush b2 = new SolidBrush(Color.White);
                g.DrawRectangle(p2, x, y, height, width);
                g.FillRectangle(b2, x, y, height, width);
            }
            else
            {
                g.DrawRectangle(p, x, y, height, width);
            }
            if (flash == true)
            {
                while (true)
                {
                    while (running2 == true)
                    {
                        if (flashing == false)
                        {

                            Pen p6 = new Pen(c, 2);
                            SolidBrush b6 = new SolidBrush(c);
                            g.FillRectangle(b6, x, y, height, width);
                            flashing = true;
                        }
                        else
                        {
                            if (c == Color.Red)
                            {
                                Pen p6 = new Pen(c, 2);
                                SolidBrush b2 = new SolidBrush(Color.Green);
                                g.FillRectangle(b2, x, y, height, width);
                                flashing = false;
                            }
                            else if (c == Color.Blue)
                            {
                                Pen p6 = new Pen(c, 2);
                                SolidBrush b2 = new SolidBrush(Color.Yellow);
                                g.FillRectangle(b2, x, y, height, width);
                                flashing = false;
                            }
                            else if (c == Color.Black)
                            {
                                Pen p6 = new Pen(c, 2);
                                SolidBrush b2 = new SolidBrush(Color.White);
                                g.FillRectangle(b2, x, y, height, width);
                                flashing = false;
                            }

                        }
                        Thread.Sleep(500);
                        continue;
                    }


                }
            }
        }
    }
}