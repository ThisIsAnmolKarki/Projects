﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Collections;
using System.Text.RegularExpressions;
using System.IO;



namespace Component1
{
    /// <summary>
    /// Partial class.
    /// </summary>
    public partial class Form1 : Form
    {
       
        //stores line drawing settings
        ArrayList longlines = new ArrayList();
       
        //Storing all the shapes in arraylist
        ArrayList shapes_name = new ArrayList();

        int refs = 0;

        //Drawing surface
        Graphics graphics;

       

        //Shape class object
        Shape s;


        //storing the x-axis and y-axiz value
        int X = 0;
        int Y = 0;
        int pointA;
        int pointB;
        //shape fill on/off
        private bool fill = false;
        private bool flash = false;
        
        //default pen color
        Color c = Color.Black;

        //RotateFlipType the shape
        static int rotate_degree = 0;
        //line count
        int count = 0;
        
        //stores the variables
        IDictionary<string, int> variable = new Dictionary<string, int>();

        /// <summary>
        /// The constructor method is a special type of method that is automatically called when an object of the class is created.
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            //string make = "command";
            //newThread = new Thread(() => draw_cmds(make)); //create the newthread passing the delegate method thread() which corresponds to the threadstart delegate(void method())
            //newThread.Start();
            graphics = panel2.CreateGraphics();
        }
        private void button1_Click(object sender, EventArgs e)
        {
          

        }
      
        /// <summary>
        /// Stores degree of rotation
        /// </summary>
        /// <returns>degree of rotation</returns>

        public void draw_cmds(string Make)
        {
            Make = Make.Trim();
            Make = Regex.Replace(Make, @"\s+", ""); //replaces all the white spaces to null
            String commands = Make.Split('(')[0];
            if (commands.Equals("circle") || commands.Equals("rectangle") || commands.Equals("triangle"))
            {
               DrawAll.GetInstance.SetDrawing(Make, c, fill,flash, X, Y);
               panel2.Refresh();
                
            }
            else if(commands.Equals("moveto"))
            {
                variable = ExtraClass.getVariables();
                string point = (Make.Split('(', ')')[1]);
                string[] value = point.Split(',');
                //checking if the value passes id interger or not
                if (!Regex.IsMatch(value[0], @"^[0-9]+$"))
                {
                    variable.TryGetValue(value[0], out X);
                }
                else
                {
                    X = int.Parse(value[0]);     
                }
                if(!Regex.IsMatch(value[1], @"^[0-9]+$"))
                {
                    variable.TryGetValue(value[1], out Y);
                }
                else
                {
                    Y = int.Parse(value[1]);
                }
            }
            else if (commands.Equals("drawto"))
            {
                Pen p4 = new Pen(c, 5);
                string point = (Make.Split('(', ')')[1]);
               
                if (!Regex.IsMatch(point.Split(',')[0], @"^[0-9]+$"))
                {
                    ConsoleTextBox.Text = "Please enter integer only in points";
                }
                else
                {
                    pointA = int.Parse(point.Split(',')[0]);
                }
                if (!Regex.IsMatch(point.Split(',')[1], @"^[0-9]+$"))
                {
                    ConsoleTextBox.Text = "Please enter integer only in points";
                }
                else
                {
                    pointB = int.Parse(point.Split(',')[1]);
                }
                //myBitmap = new Bitmap(pointA, pointB);
             
                longlines.Add(p4);
                longlines.Add(X);
                longlines.Add(Y);
                longlines.Add(pointA);
                longlines.Add(pointB);
                panel2.Refresh();
               
                //graphics.DrawLine(p4, X, Y, pointA, pointB);

            }
            else if (commands.Equals("fill"))
            {
                string color = (Make.Split('(', ')')[1]);
                switch (color)
                {
                    case "on":
                        fill = true;
                        break;
                    case "off":
                        fill = false;
                        break;
                }
           
            }
            else if (commands.Equals("flash"))
            {
                string cmd = (Make.Split('(', ')')[1]);
                switch (cmd)
                {
                    case "on":
                        flash = true;
                        Circle.running = true;
                        Rectangle.running2 = true;


                        break;
                    case "off":
                        flash = false;
                        break;
                }
              

            }
            //*****************************************************
            else if (commands.Equals("rotate"))
            {
                string cmd = (Make.Split('(', ')')[1]);
                if (!Regex.IsMatch(cmd.Split(',')[0], @"^[0-9]+$"))
                {
                    variable.TryGetValue(cmd.Split(',')[0], out rotate_degree);
                }
                else
                {
                    rotate_degree = int.Parse(cmd.Split(',')[0]);
                }

            }
            //********************************************************
            else if (commands.Equals("pen"))
            {
                string rang = (Make.Split('(', ')')[1]);

                switch (rang)
                {
                    case "red":
                        c = Color.Red;
                       
                        break;

                    case "green":
                        c = Color.Green;
                       
                        break;

                    case "yellow":
                        c = Color.Yellow;
                        
                        break;

                    case "pink":
                        c = Color.DeepPink;
                        break;

                    case "redgreen":
                        if (Circle.combination == false)
                        {
                            c = Color.Red;
                        }
                    break;

                    case "blueyellow":
                        if (Circle.combination == false)
                        {
                            c = Color.Blue;
                        }
                     break;

                    case "blackwhite":
                        if (Circle.combination == false)
                        {
                            c = Color.Black;
                        }
                     break;
                }

            }
        
        }
        /// <summary>
        /// returns the rotate degree
        /// </summary>
        /// <returns>rotate_degree</returns>
        public static int RotateShape()
        {
            return rotate_degree;
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// drawing in panel method
        /// </summary>
        /// <param name="sender">obejct class object</param>
        /// <param name="e">Paint event reference</param>
        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            shapes_name = DrawAll.GetInstance.GetShape();
           
            //overlapping the shapes
            for (int i = 0; i < shapes_name.Count; i++)
            {
            //actually drawing the shapes
                s = (Shape)shapes_name[i];
                s.Draw(graphics);  
            }
            if (longlines.Count != 0)
            {
                int no_of_draw = longlines.Count / 5;

                for (int i = 0; i < no_of_draw; i++)
                {
                    for (int j = 0; j < longlines.Count; j = j + 5)
                    {
                        graphics.DrawLine((Pen)longlines[j], (int)longlines[j + 1], (int)longlines[j + 2], (int)longlines[j + 3], (int)longlines[j + 4]);
                    }

                }

            }

        }

    
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void cmdTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void ActionTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void ActionTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                int error = 0;
                e.SuppressKeyPress = true;
                string command = ActionTextBox.Text.Trim();
                string final = command.ToLower();
                string finalCommand = ActionTextBox.Text.ToLower();
                bool get = CommandParser.GetInstance.check_commands(finalCommand);
                CommandParser.GetInstance.clear_error();

                ArrayList errorCount = new ArrayList();

                //if executing command is valid
                if (get == true)
                {
                        switch (final)
                        {
                            case "run":
                            ConsoleTextBox.Text = null;
                            bool block = false;
                            char[] delims = new[] { '\r', '\n' }; //saving all the whitespaces and empty lines
                            //int breakSingle = 0;
                            //spliiting the command lines from the whitepaces and newline and removing the whitepaces and newline
                            string[] codes = cmdTextBox.Text.ToLower().Split(delims, StringSplitOptions.RemoveEmptyEntries);
                                ArrayList error_lines = new ArrayList();
                                count = 0;
                                error_lines.Clear();
                            //executing multiline commands
                            for (int i = 0; i < codes.Length; i++)
                            {
                                count++;
                                if (codes[i].Length == 0)
                                {
                                    continue;
                                }
                                string okay = codes[i];
                                string type = CommandParser.GetInstance.type_check(okay);



                                //********************************************
                                if (type.Equals("end"))
                                {
                                    if (!block)
                                    {
                                        error++;
                                        ConsoleTextBox.AppendText("Commadn Sart is missing!Invalid Command!");
                                    }
                                    else
                                    {
                                        block = false;
                                    }
                                }
                                //***********************************************
                                if (type.Equals("invalid"))
                                {
                                    ConsoleTextBox.AppendText(Environment.NewLine + "Invalid Command on line " + count);
                                    refs++;
                                    continue;

                                }
                                //***********************************************
                              
                                //checking if the loop or method or if are active or inactive thei block executes if the others are inactive
                                if (!block && !type.Equals("end"))
                                {
                                    if (type.Equals("valid"))
                                    {
                                        if (CommandParser.GetInstance.all_check(okay))
                                        {
                                            if (error == 0)
                                            {
                                                draw_cmds(okay);
                                            }

                                        }
                                        else
                                        {
                                            error++;
                                            error_lines.Add(count);
                                        }
                                    }
                                }
                                //************END OF NORMLA COMMAND************************





                                //************************ADVANCED COMMAND EXECUTION***********************

                                if (type.Equals("variable") || type.Equals("if") || type.Equals("loop") || type.Equals("variableOperator") || type.Equals("method") || type.Equals("methodcall"))
                                {

                                    //IF COMMAND
                                    if (type.Equals("if"))
                                    {
                                        block = true;
                                        if (CommandParser.GetInstance.if_condition(okay))
                                        {
                                            if (error == 0)
                                            {
                                                ExtraClass.GetInstance.if_command(okay, codes, count, this);
                                            }
                                        }
                                        else
                                        {
                                            error++;
                                            error_lines.Add(count);
                                        }

                                    }

                                    //SINGLE IF COMMAND WITH THEN
                                    if (type.Equals("single"))
                                    {
                                        //breakSingle = count + 1;
                                        block = true;
                                    }

                                    //LOOP COMMAND
                                    if (type.Equals("loop"))
                                    {
                                        block = true;
                                        if (CommandParser.GetInstance.check_loop(okay))
                                        {
                                            if (error == 0)
                                            {
                                                ExtraClass.GetInstance.loop_comd(okay, codes, count, this);
                                            }
                                        }
                                        else
                                        {
                                            error++;
                                            error_lines.Add(count);
                                        }
                                    }

                                    //VARIABLE COMMAND
                                    if (type.Equals("variable"))
                                    {

                                        if (CommandParser.GetInstance.check_variable(okay))
                                        {
                                            if (error == 0)
                                            {
                                                ExtraClass.GetInstance.variable_command(okay);
                                            }

                                        }
                                        else
                                        {
                                            error++;
                                            error_lines.Add(count);
                                        }

                                    }

                                    //VARIABLE OPERATION COMMAND
                                    if (type.Equals("variableOperator"))
                                    {
                                        if (CommandParser.GetInstance.variable_operator(okay))
                                        {
                                            if (error == 0)
                                            {
                                                ExtraClass.GetInstance.operations(okay, this);
                                            }

                                        }
                                        else
                                        {
                                            error++;
                                            error_lines.Add(count);
                                        }
                                    }

                                    //METHOD COMMAND
                                    if (type.Equals("method"))
                                    {
                                        block = true;
                                        if (CommandParser.GetInstance.method_check(okay))
                                        {
                                            if (error == 0)
                                            {
                                                ExtraClass.GetInstance.method_run(okay, codes, count, this);
                                            }
                                        }
                                        else
                                        {
                                            error++;
                                            error_lines.Add(count);

                                        }
                                    }

                                    //METHODCALL COMMAND
                                    if (type.Equals("methodcall"))
                                    {
                                        if (CommandParser.GetInstance.methodcall_check(okay))
                                        {
                                            if (error == 0)
                                            {
                                                ExtraClass.GetInstance.method_call(okay, this);
                                            }
                                        }
                                        else
                                        {
                                            error++;
                                            error_lines.Add(count);

                                        }
                                    }
                                }
                                //***************************
                            }
                                //showing the error in the console !
                                if (error != 0)
                                {
                                    int k = 0;
                                    foreach (string description in CommandParser.GetInstance.list_error())
                                    {
                                        ConsoleTextBox.AppendText(Environment.NewLine + "\nError on line" + error_lines[k] + ":" + description);
                                        k++;
                                        //refs++;
                                    }
                                }

                            break;
                            case "reset":
                                cmdTextBox.Text = null;
                                X = 0;
                                Y = 0;
                                c = Color.Black;
                                shapes_name.Clear();
                                panel2.Text = null;
                                graphics.Clear(Color.White);
                                ConsoleTextBox.Text = "Reset to Default! \n Color:black \n X=0 \n Y=0";
                                break;

                            case "clear":
                                graphics.Clear(Color.White);
                                shapes_name.Clear();
                                ConsoleTextBox.Text = "All shapes cleared!";
                                ExtraClass.GetInstance.Clear_List();
                                break;
                        }
                       
                }
                else
                {
                    ConsoleTextBox.Text = "Please enter a valid command! \n 1.run \n 2.clear \n 3.reset";
                }
            }
        }
        /// <summary>
        /// returns all the erros stores in the COnsoleTextBox in the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">Event handeler object</param>
        private void ConsoleTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            
        }
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fileSave = new SaveFileDialog();
            fileSave.Title = "Save Text File";
            fileSave.DefaultExt = "txt";
            fileSave.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            if (fileSave.ShowDialog() == DialogResult.OK)
            {
                string path = fileSave.FileName;
                File.WriteAllText(path, cmdTextBox.Text);
                ConsoleTextBox.AppendText("File Saved: " + path);
            }

        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog loadFile = new OpenFileDialog();
            loadFile.Title = "Browse Text Files";
            loadFile.DefaultExt = "txt";
            loadFile.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            if (loadFile.ShowDialog() == DialogResult.OK)
            {
                string path = loadFile.FileName;
                string readfile = File.ReadAllText(path);
                cmdTextBox.Text = readfile;
                ConsoleTextBox.AppendText("File loaded: " + path);
            }
        }

        private void commnadsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You can pass these commands in the command box: \n 1. circle:(1parameter) \n 2.rectangle(2parameter)\n 3.triangle(3parameter)\n 4. moveto(2parameter) \n 5. drawto(2parameter) \n 6. fill(1parameter) \n7.pen(1parameter)");
        }

        private void shapesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Shapes that  can be drawn are\n 1.Circle \n2.Rectangle \n3.Triangle");
        }

        private void colorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Colors that can be used \n1.Red \n2.Green \n3.Yellow \n4.Pink");
        }

       

        private void authorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Created by: Avantika Nepal\n L6-Adanved Software Engineering!\nFinal Component");
        }
    }
   
}



