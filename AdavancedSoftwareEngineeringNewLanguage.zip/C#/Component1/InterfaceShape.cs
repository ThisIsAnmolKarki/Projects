﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Component1
{
    interface InterfaceShape
    {
        //Color is the color of the shape. fill is a to either fill the shape
        //or no and num is the number of arguemnrs for the coordinate
        void Set(Color color, bool fill,bool flash, params int[] num);

        void Draw(Graphics g);
    }
}
