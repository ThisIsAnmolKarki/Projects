﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Windows.Forms;

namespace Component1
{
    /// <summary>
    /// Main class DrawAll 
    /// </summary>
    public class DrawAll
    {
        private static DrawAll instance = null;
        private DrawAll() { }
        /// <summary>
        /// Instance of this class created using the singleton design pattern
        /// </summary>
        public static DrawAll GetInstance
        {
            get
            {
                if (instance == null)
                    instance = new DrawAll();
                return instance;
            }
        }
        ShapeClassFactory factory = new ShapeClassFactory();

        Shape s;

        ArrayList list = new ArrayList();
        IDictionary<string, int> variable = new Dictionary<string, int>();
     
        /// <summary>
        /// draw shape command: shape name
        /// </summary>
        /// <param name="Draw">command</param>
        /// <param name="c">color of the pen</param>
        /// <param name="fill">filling the shape witht he color</param>
        /// <param name="flash">flashing the color of the shape</param>
        /// <param name="num">numbers included in drawing the shape</param>
        public void SetDrawing(string Draw, Color c, bool fill, bool flash, params int[] num)
        {
            variable = ExtraClass.getVariables();
            int X = num[0];
            int Y = num[1];
            

            string commands = Draw.Split('(')[0];
           
            if (commands.Equals("circle"))
            {
                string size = (Draw.Split('(', ')')[1]);
                int radius = 0;
                if (!Regex.IsMatch(size, @"^[0-9]+$"))
                {
                    variable.TryGetValue(size, out radius);
                }
                else
                {
                    radius = int.Parse(size);
                }
                s = factory.GetShape("circle");
                s.Set(c, fill,flash, X, Y, radius);
                list.Add(s);

            }
            else if (commands.Equals("rectangle"))
            {
                string size = (Draw.Split('(', ')')[1]);
                string[] value = size.Split(',');
                int rectangle_height = 0;
                int rectangle_width = 0;
                if (!Regex.IsMatch(value[0], @"^[0-9]+$"))
                {
                    variable.TryGetValue(value[0], out rectangle_height);
                }
                else
                {
                    rectangle_height = int.Parse(value[0]);
                }
                if (!Regex.IsMatch(value[1], @"^[0-9]+$"))
                {
                    variable.TryGetValue(value[1], out rectangle_width);
                }
                else
                {
                    rectangle_width = int.Parse(value[1]);
                }
                s = factory.GetShape("rectangle");
                s.Set(c, fill,flash, X, Y, rectangle_height, rectangle_width);
                list.Add(s);

            }
            else if (commands.Equals("triangle"))
            {
                string size = (Draw.Split('(', ')')[1]);
                string[] value = size.Split(',');
                int vertex1 = 0;
                int vertex2 = 0;
                int vertex3 = 0;
                if (!Regex.IsMatch(value[0], @"^[0-9]+$"))
                {
                    variable.TryGetValue(value[0], out vertex1);
                }
                else
                {
                    vertex1 = int.Parse(value[0]);
                }
                if (!Regex.IsMatch(value[1], @"^[0-9]+$"))
                {
                    variable.TryGetValue(value[1], out vertex2);
                }
                else
                {
                    vertex2 = int.Parse(value[1]);
                }
                if (!Regex.IsMatch(value[2], @"^[0-9]+$"))
                {
                    variable.TryGetValue(value[2], out vertex3);
                }
                else
                {
                    vertex3 = int.Parse(value[2]);
                }
                s = factory.GetShape("triangle");
                s.Set(c, fill, flash, X, Y, vertex1, vertex2, vertex3);
                list.Add(s);

            }
        }
        /// <summary>
        /// getshape method store the names of all the shapes
        /// </summary>
        /// <returns>list: list of shape names</returns>
        public ArrayList GetShape()
        {
            return list;
        }
    }
}
