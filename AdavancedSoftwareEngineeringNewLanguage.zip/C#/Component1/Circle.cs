﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Drawing;

namespace Component1
{
    /// <summary>
    /// new class circle is created from te base class shape
    /// </summary>
    class Circle :Shape
    {
        int radius;
       
        bool flashing = false;

        public static bool running = false;
        public static bool combination=false;


        /// <summary>
        ///  calling  the base class constructor
        /// </summary>
        public Circle():base()
        {

        }


        /// <summary>
        /// overloading the constructor 
        /// </summary>
        /// <param name="color">the colour for the shape to be drawn in</param>
        /// <param name="fill">filling the shape with the color on/off</param>
        /// <param name="flashs">flashing the colors in the color on/off</param>
        /// <param name="x">x-axis cooerdinate</param>
        /// <param name="y">y-axis coordinate</param>
        /// <param name="radius">radius of the circle</param>
        public Circle(Color color, bool fill, bool flashs, int x, int y, int radius):base(color, fill,flashs, x, y)
        {
            this.radius = radius;
        }
   
        public override void Set(Color colour, bool fillshape, bool flash, params int[] num)
        {
            base.Set(colour, fillshape, flash, num[0], num[1]);
            this.radius = num[2];
        }


        /// <summary>
        /// the draw method of base class is overridded
        /// </summary>
        /// <param name="g">Reference of the grahics class</param>
        public override void Draw(Graphics g)
        {
            if (Form1.RotateShape() != 0)
            {
                float rotateValue = (float)Form1.RotateShape();
                g.RotateTransform((rotateValue));
            }
            Pen p = new Pen(c, 2);
            SolidBrush b = new SolidBrush(c);
            if (fillshape==true)
            {
                g.FillEllipse(b, x, y, radius, radius);
            }
            else if (fillshape==false)
            {
                Pen p2 = new Pen(c, 5);
                SolidBrush b2 = new SolidBrush(Color.White);
                g.DrawEllipse(p2, x, y, radius, radius);
                g.FillEllipse(b2, x, y, radius, radius);
            }
            else
            {
                g.DrawEllipse(p, x, y, radius, radius);
            }

            if (flash == true)
            {
                while (true)
                {
                    while (running==true)
                    {
                        if (flashing == false)
                        {
                            Pen p6 = new Pen(c, 2);
                            SolidBrush b6 = new SolidBrush(c);
                            g.FillEllipse(b6, x, y, radius, radius);
                            flashing = true;
                        }
                        else
                        {
                            if (c == Color.Red)
                            {
                                Pen p6 = new Pen(c, 2);
                                SolidBrush b2 = new SolidBrush(Color.Green);
                                g.FillEllipse(b2, x, y, radius, radius);
                                flashing = false;
                            }
                            else if (c == Color.Blue)
                            {
                                Pen p6 = new Pen(c, 2);
                                SolidBrush b2 = new SolidBrush(Color.Yellow);
                                g.FillEllipse(b2, x, y, radius, radius);
                                flashing = false;
                            }
                            else if (c == Color.Black)
                            {
                                Pen p6 = new Pen(c, 2);
                                SolidBrush b2 = new SolidBrush(Color.White);
                                g.FillEllipse(b2, x, y, radius, radius);
                                flashing = false;
                            }

                        }
                        Thread.Sleep(500);
                        continue;
                    }

                }

            }
        }
    }
}
