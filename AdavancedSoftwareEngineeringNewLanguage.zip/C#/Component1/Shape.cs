﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Component1
{
    abstract class Shape : InterfaceShape
    {
        protected Color c;
        protected int x, y;
        protected bool fillshape;
        protected bool flash;

        /// <summary>
        /// default constructor
        /// </summary>
        public Shape()
        {
            c = Color.Black;
            x = 0;
            y = 0;
        }

        /// <summary>
        ///  //paremterized contructor point to teh instance of the class
        /// </summary>
        /// <param name="colour">the colour for the shape to be drawn in</param>
        /// <param name="fill">filling the shape with the color on/off</param>
        /// <param name="flash">flashing the colors in the color on/off</param>
        /// <param name="x">x-axis coordinate</param>
        /// <param name="y">y-axis coordinate</param>
        public Shape(Color colour, bool fill,bool flash, int x, int y)
        {
            this.c = colour;
            this.fillshape = fill;
            this.flash = flash;
            this.x = x;  //x-axis coordinate
            this.y = y;  //y-axis coordiante
        }
        //overriding the draw method in interface 
        //abstract class menaing htat the base class MUST override this method
        public abstract void Draw(Graphics g);



        /// <summary>
        /// //overriding the set method from base classas virtual So that the child class may override the
        /// </summary>
        /// <param name="colour">the colour for the shape to be drawn in</param>
        /// <param name="fill">filling the shape with the color on/off</param>
        /// <param name="flashs">flashing the colors in the color on/off</param>
        /// <param name="num">all the numbers used to draw the shape</param>
        public virtual void Set(Color colour, bool fill, bool flashs, params int[] num)
        {
            c = colour;
            fillshape = fill;
            flash = flashs;
            x = num[0];
            y = num[1];
        }
    }
}
