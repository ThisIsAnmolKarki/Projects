﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Collections;

namespace Component1
{
    /// <summary>
    /// Check if given commands are valid
    /// </summary>
    public class CommandParser
    {
        private static CommandParser instance = null;

        IDictionary<string, int> variable = new Dictionary<string, int>();
        IDictionary<string, ArrayList> signature = new Dictionary<string, ArrayList>();
        /// <summary>
        /// private constructor
        /// </summary>
        private CommandParser() { }

        /// <summary>
        /// static instance of itself.
        /// </summary>
        public static CommandParser GetInstance
        {
            get
            {
                if (instance == null)
                    instance = new CommandParser();
                return instance;
            }
        }




        //store errors
        ArrayList errors = new ArrayList();



        //this is string is decalared static sot hat other classes can access it with the instance of this class
        static string Operatorcondition = null;
        /// <summary>
        /// clear error list, variables, method
        /// </summary>
        public void clear_list()
        {
            errors.Clear();

        }

        /// <summary>
        /// clear error list
        /// </summary>
        public void clear_error()
        {
            errors.Clear();
        }

        /// <summary>
        /// checks the command for run,clear,reset
        /// </summary>
        /// <param name="cmd">the command that is passed</param>
        /// <returns></returns>
        public bool check_commands(string cmd)
        {
            string command = cmd;
            if (command.Equals("run") || command.Equals("clear") || command.Equals("reset"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// checks if the passed commandis valid or not
        /// </summary>
        /// <param name="draw">the draw command</param>
        /// <returns>kind</returns>
        public string type_check(string draw)
        {
            string kind = null;
                if (draw.Contains("moveto") || draw.Contains("drawto") || draw.Contains("fill") || draw.Contains("pen") || draw.Contains("rectangle") || draw.Contains("circle") || draw.Contains("triangle") || draw.Contains("flash") || draw.Contains("rotate"))
                {
                    kind = "valid";
                }
               else if (draw.Contains("if")  && !draw.Contains("endif"))
                {
                    kind = "if";
                }
                else if (draw.Contains("then"))
                {
                    kind = "single";
                }
                else if (draw.Contains("endif") || draw.Contains("endloop") || draw.Contains("endmethod"))
                {
                        kind = "end";

                 }
                else if(draw.Contains("while") && draw.Contains("for"))
            {
                kind = "loop";
            }
                else if (draw.Contains("="))
                {
                    kind = "variable";

                }
                else if (draw.Contains("+") || draw.Contains("-") || draw.Contains("*") || draw.Contains("/"))
                {
                    kind = "variableOperator";

                }
            else if (draw.Contains("+") || draw.Contains("-") || draw.Contains("*") || draw.Contains("/"))
                {
                    kind = "operations";

                }
                else if (draw.Contains("method") && !draw.Contains("endmethod"))
            {
                if (draw.Split(' ')[0].Equals("method"))
                {
                    kind = "method";
                }
                else
                {
                    kind = "methodcall";
                }
            }
            else
                {
                kind = "invalid";

                }
            return kind;

        }
       


        /// <summary>
        /// checks the syntax of the if commmadn
        /// </summary>
        /// <param name="okay">if comamnd written in the form</param>
        /// <returns></returns>
        public bool if_condition(string okay)
        {
            okay = Regex.Replace(okay, @"\s+", "");
            string[] okay_parts = okay.Trim().Split(new String[] { "(" }, StringSplitOptions.RemoveEmptyEntries);
            string condition;
            try
            {
                if (okay_parts[0].Equals("if"))
                {
                    if(okay_parts.Length == 2)
                    {
                        condition = okay.Split('(', ')')[1].Trim();
                        if (condition.Contains("<="))
                        {
                            Operatorcondition = "<=";
                            return true;
                        }
                        else if (condition.Contains(">="))
                        {
                            Operatorcondition = ">=";
                            return true;
                        }
                        else if (condition.Contains("=="))
                        {
                            Operatorcondition = "==";
                            return true;
                        }
                        else if (condition.Contains("!="))
                        {
                            Operatorcondition = "!=";
                            return true;
                        }
                        else if (condition.Contains(">"))
                        {
                            Operatorcondition = ">";
                            return true;
                        }
                        else if (condition.Contains("<"))
                        {
                            Operatorcondition = "<";
                            return true;
                        }
                        else
                        {
                            throw new InvalidOperationException(" Operator is either missing!");
                        }
                    }
                    else
                    {
                        throw new InvalidConditionException("If statement syntax wrong!");
                    }
                }
                else
                {
                    throw new InvalidConditionException("If statement is wrong!");
                }

            }
            catch (InvalidOperationException e)
            {
                errors.Add(e.Message);
                return false;
            }
            catch (InvalidConditionException e)
            {
                errors.Add(e.Message);
                return false;
            }
        }


        /// <summary>
        /// method the returns the varibale operators
        /// </summary>
        /// <returns>Operatorcondition</returns>
        public static string getOperator()
        {
            return Operatorcondition;
        }


        /// <summary>
        /// checking hte variable syntax
        /// </summary>
        /// <param name="command">the commadn of the variable</param>
        /// <returns></returns>
        /// 
        public bool check_variable(string command)
        {
            command = Regex.Replace(command, @"\s+", "");
            string var = command.Split('=')[0];
            string char_one = var.Substring(0, 1);
            try
            {
                if (Regex.IsMatch(char_one, @"^[a-zA-Z]+$"))
                {
                    if (Regex.IsMatch(var, @"^[a-zA-Z0-9]+$"))
                    {
                        int.Parse(command.Split('=')[1]);
                        return true;
                    }
                    else
                    {
                        throw new VariableException("PLease start the variable name with only alpahabet!");
                    }
                }
                else
                {
                    throw new VariableException("PLease start the variable name with only alpahabet!");
                }
            }
            catch (VariableException e)
            {
                errors.Add(e.Message);
                return false;
            }
            catch (FormatException)
            {
                errors.Add("The vlaue of the variable can only be number!.");
                return false;
            }
        }
        /// <summary>
        /// check the method syntax
        /// </summary>
        /// <param name="command">the actual command of method decleration</param>
        /// <returns>true</returns>
        public bool method_check(string command)
        {
            try
            {
                if (!(command.Contains("(") && command.Contains(")")))
                {
                    throw new InvalidCommandException("Invalid command!");
                }
              
                string[] parts=command.Split(new string[] {"("}, StringSplitOptions.RemoveEmptyEntries);
                string value = parts[1];
                value = Regex.Replace(value, @"\s+", "");
                string cmd = parts[0] + "(" + value;
                //seperating Method methodname (value) in array 0,1,2
                string[] parts_cmd = cmd.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                string inside_value = "";
              
                if (parts_cmd[0].Equals("method"))
                {
                    if (parts_cmd.Length == 3)
                    {
                        if (Regex.IsMatch(parts_cmd[1], @"^[a-zA-Z0-9]+$"))
                        {
                            string chars = parts_cmd[1].Substring(0, 1);
                            if(Regex.IsMatch(chars, @"^[a-zA-Z]+$"))
                            {
                                string checkparameter = parts_cmd[2];
                                checkparameter = Regex.Replace(checkparameter, @"\s+", "");
                                if (!checkparameter[0].Equals('(') || !checkparameter[checkparameter.Length - 1].Equals(')'))
                                {
                                    throw new InvalidMethodException("Invalid Mehtod commadn Syntax!");
                                }
                                else
                                {
                                    inside_value = parts_cmd[2].Trim().Split('(', ')')[1];
                                    if (inside_value.Length > 0)
                                    {
                                        for(int i=1; i< checkparameter.Length - 1; i++)
                                        {
                                            if (!(Char.IsLetter(checkparameter[i]) || checkparameter[i].Equals(',')))
                                            {
                                                throw new InvalidParameterException("Invalid Parameter of the method!");

                                            }
                                        }
                                    }
                                    else
                                    {
                                        return true;
                                    }
                                }
                            }
                            else
                            {
                                throw new InvalidMethodException("Start the method name with alphabet not a number!");
                            }
                        }
                        else
                        {
                            throw new InvalidMethodException("Method name cannot contain specials characters except for alphabets!");
                        }
                    }
                    else
                    {
                        throw new InvalidCommandException("Method command is invalid");
                    }
                }
                else
                {
                    throw new InvalidCommandException("Invalid Command Name");
                }
            }
            catch(InvalidCommandException e)
            {
                errors.Add(e.Message);
                return false;
            }
            catch(InvalidMethodException e)
            {
                errors.Add(e.Message);
                return false;
            }
            catch (InvalidParameterException e)
            {
                errors.Add(e.Message);
                return false;
            }
            return true;
        }
        /// <summary>
        /// checking hte syntac of the method call
        /// </summary>
        /// <param name="command">method call commnad</param>
        /// <returns></returns>

        public bool methodcall_check(string command)
        {
            signature = ExtraClass.getMethodSignature();
            string mainName = command.Split('(')[0];
            mainName = Regex.Replace(mainName, @"\s+", "");
            string inside_value = command.Trim().Split('(', ')')[1];
            int param_count = 0;
            if (inside_value.Contains(','))
            {
                param_count = inside_value.Split(',').Length;
            }
            else
            {
                if (inside_value.Length > 0)
                {
                    param_count = 1;
                }
                else
                {
                    param_count = 0;
                }
            }
            string sign = mainName + "," + param_count;
            try
            {
              
                if (signature.ContainsKey(sign))
                {
                    return true;
                }
                else
                {
                    throw new InvalidMethodException("Method could not be found!");
                }
            }
            catch(InvalidMethodException e)
            {
                errors.Add(e.Message);
                return false;
            }
        }
        /// <summary>
        /// checking if the variable operator is '+','-','*','/'
        /// </summary>
        /// <param name="command">the variable operator condiiton</param>
        /// <returns></returns>
        public bool variable_operator(string command)
        {
            variable = ExtraClass.getVariables();
            command = Regex.Replace(command, @"\s+", "");  //replaces any unnesseary space
            string[] param = command.Trim().Split(new Char[] { '+', '-', '*', '/' }, StringSplitOptions.RemoveEmptyEntries);
            try
            {
                if (variable.ContainsKey(param[0]))
                {
                    return true;
                }
                else
                {
                    throw new VariableException("Variabel not found!");
                }
            }
            catch(VariableException e)
            {
                errors.Add(e.Message);
                return false;
            }
        }
     
        //**********************************************
        //loopcheck
        /// <summary>
        /// checks the syntax of the loop command
        /// </summary>
        /// <param name="commands">the actual loop command</param>
        /// <returns>true</returns>
        public bool check_loop(string commands)
        {
            variable = ExtraClass.getVariables();
            commands = Regex.Replace(commands, @"\s+","");
            string[] cmds = commands.Split(new string[] { "for" }, StringSplitOptions.RemoveEmptyEntries);
            string[] Condition = { };
            try
            {
                if (!cmds[0].Equals("while"))
                {
                    throw new InvalidCommandException("Invalid name");
                }
                if (cmds.Length != 2)
                {
                    throw new InvalidCommandException("Invalid loop statemnt");
                }
                Condition = cmds[1].Split(new String[] { "<=", ">=", "<", ">" }, StringSplitOptions.RemoveEmptyEntries);
                if (Condition.Length == 1)
                {
                    throw new InvalidParameterException("Loop condiotn is wrong!\n '<=','>=','<','>'");
                }
                if (!Regex.IsMatch(cmds[1], @"^[0-9]+$"))
                {
                    string vari = Condition[0].ToLower().Trim();
                    if (!variable.ContainsKey(vari))
                    {
                        throw new VariableException("Variable not found: " + vari);
                    }
                }

            }
            catch(InvalidCommandException e)
            {
                errors.Add(e.Message);
                return false;
            }
            catch (VariableException e)
            {
                errors.Add(e.Message);
                return false;
            }
            catch (InvalidParameterException e)
            {
                errors.Add(e.Message);
                return false;
            }
            return true;
        }
        //loopcheckends
        //************************************************


        /// <summary>
        /// cheskthe syntax of all the commands passed in the commnad prompt in the form
        /// </summary>
        /// <param name="commands">the commands</param>
        /// <returns>flase</returns>
        public bool all_check(string commands)
        {
            variable = ExtraClass.getVariables();
            string final_draw = commands.Split('(')[0].Trim();
           

            try
            {
                if (final_draw.Equals("moveto") || final_draw.Equals("drawto") || final_draw.Equals("circle") || final_draw.Equals("fill") || final_draw.Equals("pen") || final_draw.Equals("rectangle") || final_draw.Equals("triangle")|| final_draw.Equals("flash") || final_draw.Equals(variable) || final_draw.Equals("rotate"))
                {
                    string a = null;
                    string[] param = null;

                    try
                    {
                        if (commands.Split('(', ')').Length >= 1)
                        {
                            a = commands.Split('(', ')')[1];

                            //a = Regex.Replace(a, @"\s+", "");
                            param = a.Split(',');
                        }
                        else if(commands.Split('(', ')') == null)
                        {
                            throw new InvalidParameterException("Parameter missing!");
                        }
                        
                    }
                    catch (InvalidParameterException e)
                    {
                        errors.Add(e.Message);
                        return false;
                    }



                    //moveto and drawto and rectangle command 2 paremeter checking!
                    if (final_draw.Equals("moveto") || final_draw.Equals("drawto"))
                    {

                        try
                        {
                            if (param.Length == 2)
                            {
                            
                                if (Regex.IsMatch(param[0], @"^[0-9]+$") && Regex.IsMatch(param[1], @"^[0-9]+$"))
                                {
                                    int.Parse(param[0]);
                                    int.Parse(param[1]);
                                   
                                    //return false;
                                }
                             
                            }
                            else
                            {
                                throw new InvalidParameterException("2 PARAMETERS REQUIRED!");
                            }
                            
                        }
                        
                        catch (InvalidParameterException e)
                        {
                            errors.Add(e.Message);
                            return false;
                        }
                       return true;

                    }
                    //else
                    //{
                    //    throw new InvalidCommandException("Invalid Command! Please enter a valid command!okay");
                    //}

                    //checking the fill and color command
                    if (final_draw.Equals("pen"))
                    {
                        try
                        {
                            if (a.Contains(','))
                            {
                                throw new InvalidParameterException("Pass only one color");
                            }
                            else if (Regex.IsMatch(a, @"^[0-9]+$"))
                            {
                                throw new InvalidParameterException("Pass only  color");
                            }
                            else
                            {
                                if (a.Equals("red") || a.Equals("green") || a.Equals("yellow") || a.Equals("pink")|| a.Equals("redgreen") || a.Equals("blueyellow") || a.Equals("blackwhite"))
                                {
                                    return true;
                                }
                                else
                                {
                                    throw new InvalidParameterException("This color does not exist!");
                                }

                            }
                        }
                        catch (InvalidParameterException e)
                        {
                            errors.Add(e.Message);
                            return false;
                        }
                        //eturn true;
                    }
                    //else
                    //{
                    //    throw new InvalidCommandException("Invalid Command! Please enter a valid command!okay");
                    //}


                    //checking fill commadn
                    if (final_draw.Equals("fill"))
                    {
                        try
                        {
                            if (!a.Contains(','))
                            {
                                if (a.Equals("on") || a.Equals("off"))
                                {
                                    return true;
                                }
                                else
                                {
                                    throw new InvalidParameterException("Please pass the value on/off");
                                   
                                }

                            }
                            else
                            {
                                throw new InvalidParameterException("Please pass only one value on/off");
                            }
                        }
                        catch (InvalidParameterException e)
                        {
                            errors.Add(e.Message);
                            return false;
                        }


                    }






                    if (final_draw.Equals("flash"))
                    {
                        try
                        {
                            if (!a.Contains(','))
                            {
                                if (a.Equals("on") || a.Equals("off"))
                                {
                                    return true;
                                }
                                else
                                {
                                    throw new InvalidParameterException("Please pass the value on/off");
                                    
                                }

                            }
                            else
                            {
                                throw new InvalidParameterException("Please pass only one value on/off");
                            }
                        }
                        catch (InvalidParameterException e)
                        {
                            errors.Add(e.Message);
                            return false;
                        }


                    }



                    if (final_draw.Equals("rotate"))
                    {
                        try
                        {
                            if (param.Length == 1)
                            {
                                if (!Regex.IsMatch(param[0], @"^[0-9]+$"))
                                {
                                    if (variable.ContainsKey(param[0]))
                                    {
                                        return true;
                                    }
                                    else
                                    {
                                        throw new VariableException("Variable: " + param[0] + " does not exist");
                                    }
                                }
                                else
                                {
                                    int.Parse(param[0]);
                                    return true;
                                }
                            }
                            else
                            {
                                throw new InvalidParameterException("Only 1 parameter required.");
                            }

                        }
                        catch (FormatException)
                        {
                            errors.Add("Degree should be in numbers (0-9).");
                            return false;
                        }
                        catch (InvalidParameterException e)
                        {
                            errors.Add(e.Message);
                            return false;
                        }
                        catch (VariableException e)
                        {
                            errors.Add(e.Message);
                            return false;
                        }
                    }

                        //else
                        //{
                        //    throw new InvalidCommandException("Invalid Command! Please enter a valid command!");
                        //}

                        //checking triangle command
                        if (final_draw.Equals("triangle"))
                    {
                        try
                        {
                            if (param.Length == 3)
                            {
                                if (!Regex.IsMatch(param[0], @"^[0-9]+$") || !Regex.IsMatch(param[1], @"^[0-9]+$") || !Regex.IsMatch(param[2], @"^[0-9]+$"))
                                {
                                    if (variable.ContainsKey(param[0]) || variable.ContainsKey(param[1]) || variable.ContainsKey(param[2]))
                                    {
                                        return true;

                                    }
                                    else
                                    {
                                        throw new VariableException("Variable not found!");

                                    }
                                }

                                else
                                {
                                    int.Parse(param[0]);
                                    int.Parse(param[1]);
                                    int.Parse(param[2]);
                                    return true;

                                }
                            }
                            else
                            {
                                throw new InvalidParameterException("Three paremeters expected!");
                            }
                        }
                        catch (InvalidParameterException e)
                        {
                            errors.Add(e.Message);
                            return false;
                        }
                        catch (VariableException e)
                        {
                            errors.Add(e.Message);
                            return false;
                        }

                    }

                    //checking rectangle
                    if (final_draw.Equals("rectangle"))
                    {
                        try
                        {
                            if (param.Length == 2)
                            {
                                if (!Regex.IsMatch(param[0], @"^[0-9]+$") || !Regex.IsMatch(param[1], @"^[0-9]+$"))
                                {
                                    if (variable.ContainsKey(param[0]) || variable.ContainsKey(param[1]))
                                    {
                                        return true;

                                    }
                                    else
                                    {
                                        throw new VariableException("Variable not found!");

                                    }
                                }

                                else
                                {
                                    int.Parse(param[0]);
                                    int.Parse(param[1]);
                                    return true;
                                }
                            }
                            else
                            {
                                throw new InvalidParameterException("Two paremeters expected!");
                            }
                        }
                        catch (InvalidParameterException e)
                        {
                            errors.Add(e.Message);
                            return false;
                        }
                        catch (VariableException e)
                        {
                            errors.Add(e.Message);
                            return false;
                        }

                    }

                    //end of rectangle code

                    //checking circle command
                    if (final_draw.Equals("circle"))
                    {

                        try
                        {
                            if (param.Length == 1)
                            {
                                if (!Regex.IsMatch(param[0], @"^[0-9]+$"))
                                {
                                    if (variable.ContainsKey(param[0]))
                                    {
                                        return true;

                                    }
                                    else
                                    {
                                        throw new VariableException("Variable not found!");

                                    }
                                }
                                else
                                {
                                    int.Parse(param[0]);
                                    return true;
                                }
                            }
                            else
                            {
                                throw new InvalidParameterException("Only one paremeters expected!");
                            }
                                //HEREHEREHEREHEREHEREHERE
                              
                        }
                        

                        catch (InvalidParameterException e)
                        {
                            errors.Add(e.Message);
                            return false;
                        }
                        catch (VariableException e)
                        {
                            errors.Add(e.Message);
                            return false;
                        }

                    }

                }
                else
                {
                    throw new InvalidCommandException("Invalid Command! Please enter a valid command!");
                }
            }
            catch (InvalidCommandException e)
            {
                errors.Add(e.Message);
                return false;
            }
            return false;

        }
        /// <summary>
        /// method returns the list of the errors
        /// </summary>
        /// <returns>errors</returns>
        public ArrayList list_error()
        {
            return errors;
        }

    }
}

