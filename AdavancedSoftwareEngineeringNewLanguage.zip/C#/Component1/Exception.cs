﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Component1
{
    class Exceptions
    {
    }
   /// <summary>
   /// Making a custome exception for invalid commands inheriting form the main exception class
   /// </summary>
    public class InvalidCommandException : Exception
    {
        /// <summary>
        /// Custome exception: InvalidCommandException 
        /// </summary>
        /// <param name="message">custome message passed for this exception</param>

        public InvalidCommandException(string message) : base(message)
        {

        }
    }

    /// <summary>
    /// Making a custome exception for invalid methods inheriting form the main exception class
    /// </summary>
    public class InvalidMethodException : Exception
    {
        /// <summary>
        /// Custome exception: InvalidMethodException 
        /// </summary>
        /// <param name="message">custome message passed for this exception</param>

        public InvalidMethodException(string message) : base(message)
        {

        }
    }



    /// <summary>
    /// Making a custome exception for invalid variable inheriting form the main exception class
    /// </summary>
    public class VariableException : Exception
    {
        /// <summary>
        /// Custome exception: VariableException
        /// </summary>
        /// <param name="message">custome message passed for this exception</param>
        public VariableException(string message) : base(message)
        {

        }
    }


    /// <summary>
    /// Making a custome exception for invalid variable operations inheriting form the main exception class
    /// </summary>

    public class InvalidOperationException : Exception
    {
        /// <summary>
        ///  Custome exception: InvalidOperationException
        /// </summary>
        /// <param name="message">custome message passed for this exception</param>
        public InvalidOperationException(string message) : base(message)
        {

        }
    }




    /// <summary>
    /// Making a custome exception for invalid conditions inheriting form the main exception class
    /// </summary>
    public class InvalidConditionException : Exception
    {
        /// <summary>
        /// Custome exception: InvalidConditionException
        /// </summary>
        /// <param name="message">custome message passed for this exception</param>
        public InvalidConditionException(string message) : base(message)
        {

        }
    }
    /// <summary>
    /// Making a custome exception for invalid parameter passed inheriting form the main exception class
    /// </summary>

    public class InvalidParameterException : Exception
    {
        /// <summary>
        /// Custome exception: InvalidParameterException
        /// </summary>
        /// <param name="message">custome message passed for this exception</param>
        public InvalidParameterException(string message) : base(message)
        {

        }
    }
}
