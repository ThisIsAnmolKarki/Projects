﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Component1
{
   class ShapeClassFactory
    {
      public Shape GetShape(String name)
        {
            name = name.ToLower().Trim();

            if (name.Equals("circle")) 
            {
                return new Circle();
            }
            else if (name.Equals("rectangle"))
            {
                return new Rectangle();
            }
            else if (name.Equals("triangle"))
            {
                return new Triangle();
            }
            else
            {  
                System.ArgumentException names = new System.ArgumentException("Factory error: does not exist");
                throw names;
            }


        }
    }
}
