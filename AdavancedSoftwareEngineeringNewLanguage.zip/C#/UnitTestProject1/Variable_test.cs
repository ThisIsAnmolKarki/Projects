﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Component1;
namespace UnitTestProject1
{
    [TestClass]
    public class Variable_test
    {
        Form1 frm = new Form1();
        [TestMethod]
        public void Variable_check()
        {
            //VariableException decleration
            string[] text = { "width = 10", "rectangle=50", "height= 5" };
            foreach (string text_check in text)
            {
                //checking hte variable syntax
                Assert.IsTrue(CommandParser.GetInstance.check_variable(text_check));
                //checking if the variable is being added in the list or not
                Assert.IsTrue(ExtraClass.GetInstance.variable_command(text_check));
            }
            //use of variable operations
            string[] text_operators = { "width+10", "rectangle-20", "height*5", "height/5" };
            foreach(string text_check in text_operators)
            {
                //checking if the syntac and sign of the operation is correct
                Assert.IsTrue(CommandParser.GetInstance.variable_operator(text_check));
                //checking if the execution of the operators is correct or not
                Assert.IsTrue(ExtraClass.GetInstance.operations(text_check, frm));
            }
        }
    }
}
