﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Component1;
namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        /// <summary>
        ///calling the class to be tested in the test method
        /// </summary>
       

        //[TestMethod]
        //public void validity_check()
        //{
           
        //    var expectedString = "moveto";
        //    var result = new CommandParser().type_check();
        //    Assert.AreEqual(expectedString, result);
           
        //}

        /// <summary>
        /// 1. correct cmmand and paremerter passed
        /// 2. wrong commansd passed wiht right paramenter
        /// </summary>
        [TestMethod]
        public void moveto_check()
        {
            Assert.IsTrue(CommandParser.GetInstance.all_check("moveto(30,30)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("movto(30,30)"));
        }


        /// <summary>
        /// 1. correct cmmand and paremerter passed
        /// 2. wrong commansd passed wiht right paramenter
        /// </summary>

        [TestMethod]
        public void draw_check()
        {
            //Assert.IsFalse(CommandParser.GetInstance.all_check("drawto(30,y)"));
            Assert.IsTrue(CommandParser.GetInstance.all_check("drawto(30,30)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("dawto(30,30)"));
        }

        /// <summary>
        /// checking the action line commands by making an array of the commands
        /// </summary>
        [TestMethod]

        public void commnds_check()
        {
            string[] cmds = { "run", "reset", "clear" };
            foreach (string commands in cmds)
            {
                Assert.IsTrue(CommandParser.GetInstance.check_commands(commands));

            }
        }

        /// <summary>
        /// Check Rotate command validity
        /// </summary>
        [TestMethod]
        public void check_rotate_command()
        {
            //valid command with valid parameter
            Assert.IsTrue(CommandParser.GetInstance.all_check("rotate(20)"));
            //Invalid parameter
            Assert.IsFalse(CommandParser.GetInstance.all_check("rotate(xy, 290)"));
            //Invalid command name
            Assert.IsFalse(CommandParser.GetInstance.all_check("rotae(120)"));
        }

        /// <summary>
        /// 1.fill on test
        /// 2.fill off test
        /// 3. anything else passed except on or off
        /// </summary>
        [TestMethod]
        public void fill_check()
        {
            Assert.IsTrue(CommandParser.GetInstance.all_check("fill(on)"));
            Assert.IsTrue(CommandParser.GetInstance.all_check("fill(off)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("fill(abc)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("fill(on,off)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("fill(89)"));
        }


        /// <summary>
        /// 1. correct command and paremeter
        /// 2. correct command and wrong paremeter
        /// 3.wrong command and correct paremeter
        /// 4.correct command wrong number of parameters
        /// </summary>

        [TestMethod]
        public void circle_check()
        {
            Assert.IsTrue(CommandParser.GetInstance.all_check("circle(50)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("circle(off)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("circel(50)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("circle(50,30)"));
        }




        /// <summary>
        /// 1. correct command and paremeter
        /// 2. correct command and wrong paremeter
        /// 3.wrong command and correct paremeter
        /// 4.correct command wrong number of parameters
        /// </summary>

        [TestMethod]
        public void rectangle_check()
        {
            Assert.IsTrue(CommandParser.GetInstance.all_check("rectangle(50,20)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("rectangle(off)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("rectangel(50)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("rectangle(50)"));
        }



        /// <summary>
        /// 1. correct command and paremeter
        /// 2. correct command and wrong paremeter
        /// 3. correct command wrong number of parameters
        /// 4. wrong command and correct paremeter
        /// </summary>

        [TestMethod]
        public void pen_check()
        {
            Assert.IsTrue(CommandParser.GetInstance.all_check("pen(red)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("pen(magenta)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("pen(red,pink)"));
           Assert.IsFalse(CommandParser.GetInstance.all_check("pen(50)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("pne(red)"));
        }

        /// <summary>
        /// 1. correct command and paremeter
        /// </summary>
        /// 2. correct command and wrong paremeter
        /// 3.wrong command and correct paremeter
        /// 4.correct command wrong number of parameters
        /// 
        [TestMethod]
        public void triangle_check()
        {
            Assert.IsTrue(CommandParser.GetInstance.all_check("triangle(50,20,60)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("triangle(off)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("triangle(50)"));
            Assert.IsFalse(CommandParser.GetInstance.all_check("triangel(50,40,30)"));
        }
    }
}
