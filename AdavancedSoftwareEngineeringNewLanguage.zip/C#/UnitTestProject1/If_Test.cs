﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Component1;

namespace UnitTestProject1
{
    [TestClass]
    public class If_Test
    {
        Form1 frm = new Form1();

        [TestMethod]
        public void check_if()
        {
            string variable = "radius=10";
            //chekingthe variable syntax
            Assert.IsTrue(CommandParser.GetInstance.check_variable(variable));
            //chekinng the variable list add and execute
            Assert.IsTrue(ExtraClass.GetInstance.variable_command(variable));

            string[] commands = { "if (radius=10)\nthen\ncircle (radius)", "if (radius==10)\ncircle (radius)\nendif" };
            foreach (string type in commands)
            {
                string[] list = type.Split('\n');
                string if_command = "if (radius==10)";
                int line_found = 1;
                //cheking the syntax of the if command
                Assert.IsTrue(CommandParser.GetInstance.if_condition(if_command));
                //checking the actual execution of the if command
                Assert.IsTrue(ExtraClass.GetInstance.if_command(if_command, list, line_found, frm));
            }

            string[] cmds = { "if (radius=10)\nthen\ncircle (radius)\nrectangle (radius,radius)" };
            foreach (string type in cmds)
            {
                string[] list = type.Split('\n');
                string if_command = "if (radius==10)";
                int line_found = 1;
                //cheking the syntax of the if command
                Assert.IsTrue(CommandParser.GetInstance.if_condition(if_command));
                //checking the actual execution of the if command
                Assert.IsFalse(ExtraClass.GetInstance.if_command(if_command, list, line_found, frm));
            }

            string[] comds = { "if (radius=10)\ncircle (radius)\nrectangle (radius,radius)" };
            foreach (string type in comds)
            {
                string[] list = type.Split('\n');
                string if_command = "if (radius==10)";
                int line_found = 1;
                //cheking the syntax of the if command
                Assert.IsTrue(CommandParser.GetInstance.if_condition(if_command));
                //checking the actual execution of the if command
                Assert.IsFalse(ExtraClass.GetInstance.if_command(if_command, list, line_found, frm));
            }

        }
    }
}
