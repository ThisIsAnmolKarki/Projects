﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Component1;

namespace UnitTestProject1
{
    [TestClass]
    public class Method_Test
    {
        Form1 frm = new Form1();
        [TestMethod]
        public void Method_command()
        {
            string[] codes = { "Method pMethod ()\ncircle (100)\nEndmethod", "Method myMethod (radius, width, height)"+
                    "\ncircle (radius)\nrectangle (width, height)\nEndmethod" };
            string lines;
            int current_line = 1;
            //checking the first 2 lines of the codes if they are parameterized of non parameterized method
            for (int i = 0; i < codes.Length; i++)
            {
                if (i == 0)
                {
                    lines = "Method pMethod ()";
                    //Method without parameter     
                }
                else
                {
                    //Metho with parameter
                    lines = "Method myMethod (radius, width, height)";
                }
                string[] commnads = codes[i].Split('\n');
                //cheking the execution and logiic of the method only
                Assert.IsTrue(CommandParser.GetInstance.method_check(lines));
                Assert.IsTrue(ExtraClass.GetInstance.method_run(lines, commnads, current_line, frm));
            }
            string[] method_call = { "pMethod()", "myMethod(10,20,30)" };
            foreach (string command in method_call)
            {
                //checking the syntax of the methodcall declerationd
                Assert.IsTrue(CommandParser.GetInstance.methodcall_check(command));
                //cheking the execution and logiic of the methodcall only
                Assert.IsTrue(ExtraClass.GetInstance.method_call(command, frm));
            }
        }
    }
}
