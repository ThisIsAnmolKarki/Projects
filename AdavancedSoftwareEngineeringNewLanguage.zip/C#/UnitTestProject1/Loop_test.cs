﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Component1;

namespace UnitTestProject1
{
    [TestClass]
    public class Loop_test
    {
        Form1 frm = new Form1();

        [TestMethod]
        public void Loop_command()
        {
            string[] var = { "count = 1", "radius = 20" };
            foreach (string vars in var)
            {
                //chekingthe variable syntax
                Assert.IsTrue(CommandParser.GetInstance.check_variable(vars));
                //chekinng the variable list add and execute
                Assert.IsTrue(ExtraClass.GetInstance.variable_command(vars));
            }

            string text = "while for count <=5\ncircle (radius)\nradius+10\ncount+1\nendloop";
            string[] command = text.Split('\n');
            string loop_cmd = "while for count <=5";
            int current_line = 1;
            //checking the syntax of the loop command
            Assert.IsTrue(CommandParser.GetInstance.check_loop(loop_cmd));
            //checking if the actual execution of the loop command and login is corretn or not
            Assert.IsTrue(ExtraClass.GetInstance.loop_comd(loop_cmd, command, current_line, frm));




            string texts = "while for count <=5\ncircle (radius)\nradius+10\ncount+1";
            string[] commands = texts.Split('\n');
            string loop_cmds = "while for count <=5";
            int current_lines = 1;
            //checking the syntax of the loop command
            Assert.IsTrue(CommandParser.GetInstance.check_loop(loop_cmds));
            //checking if the actual execution of the loop command and login is corretn or not
            Assert.IsFalse(ExtraClass.GetInstance.loop_comd(loop_cmds, commands, current_lines, frm));
        }
    }
}
