<?php
$search = $_POST["searchinp"];
// exit();
header("Location:../productCategory.php?search=$search");
