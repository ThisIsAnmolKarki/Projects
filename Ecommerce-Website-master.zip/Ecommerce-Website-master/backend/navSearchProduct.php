<?php

$searchProduct = $_POST["searchProduct"];
