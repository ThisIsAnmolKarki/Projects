<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    
    <title>Snap Up</title>
</head>
  <body>
  <?php
    include('nav.php');
    ?>
    <br>
    <h2 style="text-align:center">Return and Refund Policy</h2>
    <p style="font-size: 18px; padding: 10px; margin-left: 50px; margin-right: 50px;">
        We’re sorry your order didn’t work out. Although orders cannot be returned, they can be exchanged within 2 days of purchase. 
        <br><br>Returned items must be in the exact same condition as they were received. Please note that a refund is not guaranteed if the product is found to be damaged or is without original tags and packaging. 
        <br><br>Upon receipt, you need to come to store to exchange the products. Moreover, confirmation will be communicated via email.
    </p>
<!-- footer -->
<?php
    include('footer.php');
    ?>

 
  </body>
</html>