<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="widtd=device-widtd, initial-scale=1.0">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@2.0.2/css/boxicons.min.css">
    <link rel="stylesheet" href="./trader.css">
    <link rel="stylesheet" href="./admin.css">
    <title>Snap Up</title>
</head>
<body>
       <?php
        include('admin.php')
        ?> 

<div class="col-lg-5 mt-5" style="padding-left: 20px;">
<ul class="list-group ">
  <li class="list-group-item ">
  <p>Customer Name</p>
  <p>Products Ordered</p>
  <p>Category</p>
    </li>
   
</div>
</body>
</html>